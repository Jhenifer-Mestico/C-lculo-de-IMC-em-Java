/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imc;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
public class IMC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float peso, estatura, imc;
peso = Float.parseFloat(JOptionPane.showInputDialog (null, "Digite o peso (em Kg): ", "Dado",
JOptionPane.INFORMATION_MESSAGE) );
estatura = Float.parseFloat(JOptionPane.showInputDialog
(null, "Digite a estatura (em m): ", "Dado",
JOptionPane.INFORMATION_MESSAGE) );
imc = peso / (estatura*estatura);
JOptionPane.showMessageDialog (null, "Seu IMC é: " + imc + " Kg/m²", "IMC",
JOptionPane.INFORMATION_MESSAGE);
}
    }
    







